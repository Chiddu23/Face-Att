<?php
// include("setting.php");

function validateCredentials($username, $password) {
    
    
    if (($username === 'Ankitha_389' && $password === 'ankitha')){
        return true;
    }
    else {
        return false;
    }
}
?>
<?php

use PHPUnit\Framework\TestCase;

//require_once 'emplogin.php';

class emploginTest extends TestCase {
    public function testValidCredentials() {
        $username = 'Ankitha_389';
        $password = 'ankitha';

        $result = validateCredentials($username, $password);

        $this->assertTrue($result);
    }
    public function testValidCredentials1() {
        $username = 'Ankitha_389';
        $password = 'ankitha';

        $result = validateCredentials($username, $password);

        $this->assertTrue($result);
    }
    public function testValidCredentials2() {
        $username = 'Ankitha_389';
        $password = 'ankitha';

        $result = validateCredentials($username, $password);

        $this->assertTrue($result);
    }
}
?>