<!DOCTYPE html>
<html>
    <head>
        <title>PHP PROGRAM.php</title>
    </head>
    <body>
        // Scalar types variables that store only 1 value 
        // Compound types arrays...
        <p>
            <?php
            print "<b>Welcome to my home page</b>";
            $a = 10;
            print "<br>Printing a variable <br> Value of a is $ a";
            $s1 = "String";
            $s2 = "Concatenation";
            $s = $s1." ".$s2;
            print "<br>$s<br>";
            print "Today is:";
            print date("l d m jS"); // S is for rd in the program and j is for the date
            ?>
        </p>
    </body>
</html>