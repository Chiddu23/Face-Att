<!DOCTYPE html>
<html>
    <head>
        <title> Login Page </title>
        <link href="login.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="log">
            <img src="download (4).jpeg"/><br><br><br>
            <form action="empverify.php" method="post">
                <label> User Name: <input type = "Text" name = "un"/> </label><br><br><br>
                <label> Password: <input type = "password" name ="pwd"/> </label><br><br><br>
                <button type="submit" style="border-style:groove;border-radius:7px;padding:7px 10px;left:50%">Log In</button>  
            </form>
        </div>
</body>
</html>
